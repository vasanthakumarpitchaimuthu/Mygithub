class Api::V1::ApiController < ApplicationController
  respond_to :json
end
