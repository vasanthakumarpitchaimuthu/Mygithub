module Api::V1::RegistrationsHelper
end
