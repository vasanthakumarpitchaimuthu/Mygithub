module Api::V1::JobsHelper
end
