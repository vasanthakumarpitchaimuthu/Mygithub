class ReportIssue < ActiveRecord::Base
  belongs_to :job
end
