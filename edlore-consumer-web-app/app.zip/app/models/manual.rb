class Manual < ActiveRecord::Base
end
