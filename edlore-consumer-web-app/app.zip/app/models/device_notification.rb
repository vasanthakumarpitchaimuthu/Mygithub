class DeviceNotification < ActiveRecord::Base
end
