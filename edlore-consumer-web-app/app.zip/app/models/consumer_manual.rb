class ConsumerManual < ActiveRecord::Base
end
