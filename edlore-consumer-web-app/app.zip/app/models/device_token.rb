class DeviceToken < ActiveRecord::Base
  belongs_to :user
end
