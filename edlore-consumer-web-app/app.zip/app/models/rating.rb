class Rating < ActiveRecord::Base
end
